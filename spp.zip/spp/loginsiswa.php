<div class="container pt-5">
    <div class="row justify-content-center">
        <div class="col-4">
            <div class="card">
                <div class="card-header">Login Siswa</div>
                <div class="card-body">
                    <form action="index.php?aksi=loginsiswa" method="post">
                        <div class="form-group">
                            <input type="text" name="nisn" class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="text" name="nis" class="form-control">
                        </div>
                        <button name="login" class="btn btn-primary" id="loginB">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>